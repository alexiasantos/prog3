package controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import interfaces.IReferenciaAcaoNegocio;
import interfaces.ICrudControleNegocio;
import interfaces.IDAO;
import modelo.Tabela;
import persistencia.DAOGeneric;
import util.Retorno;

public abstract class CrudControle<TABELA extends Tabela<TipoPK>, TipoPK> extends Controle
		implements ICrudControleNegocio<TABELA, TipoPK> {
	public static final String LISTAR_TODOS = "listarTodos";
	public static final String PROCURAR = "procurar";
	public static final String EDITAR = "editar";
	public static final String NOVO = "novo";
	public static final String APAGAR = "apagar";
	public static final String ALTERAR = "alterar";
	public static final String INCLUIR = "incluir";
	protected IDAO dao;

	public CrudControle() {
		dao = DAOGeneric.getIntancia();
		this.tabelaClass = this.getNovoObjeto();
	}
	

	@Override
	public List<TABELA> listar() {
		return dao.listar(this.getNovoObjeto());
	}

	@Override
	public List<TABELA> procurar(TABELA tab) {
		List<TABELA> list = dao.procurar(tab);
		return list;
	}

	@Override
	public Retorno incluir(TABELA tab) {
		Retorno retorno = dao.incluir(tab);
		return retorno;
	}

	@Override
	public Retorno alterar(TABELA tab) {
		Retorno retorno = dao.alterar(tab);
		return retorno;
	}

	@Override
	public Retorno remover(TABELA objPk) {		
		return dao.remover(objPk);
	}

	@Override
	public TABELA editar(TABELA objPk) {
		return dao.getObjeto(objPk);

	}

	@Override
	public abstract TABELA getNovoObjeto();
	
// PARTE NOVA
	

	protected Retorno acaoRemover(String acao) {
		
		Retorno ret = this.remover();
		if(ret.isSucesso()){
			ret.setSucesso(true);
			ret.setMensagem("Remo��o na tabela "+ this.tabelaClass.getTabelaNome()+" realizada com sucesso!");
			ret.setAcao(LISTAR_TODOS);
		}else{
			ret.setSucesso(false);
			ret.setMensagem("Remo��o na tabela "+ this.tabelaClass.getTabelaNome()+" falhou! \n Erro:"+ret.getMensagem());
			ret.setAcao(ACAO_PADRAO);
		}
		return ret;
	}

	protected Retorno acaoAlterar(String acao) {
		Retorno ret = this.alterar();
		if(ret.isSucesso()){
			ret.setSucesso(true);
			ret.setMensagem("Altera��o na tabela "+ this.tabelaClass.getTabelaNome()+" realizada com sucesso!");
			ret.setAcao(ACAO_PADRAO);
		}else{
			ret.setSucesso(false);
			ret.setMensagem("Altera��o na tabela "+ this.tabelaClass.getTabelaNome()+" falhou! \n Erro:"+ret.getMensagem());
			ret.setAcao(EDITAR);
		}
		return ret;
	}

	protected Retorno acaoIncluir(String Acao) {
		Retorno ret = this.incluir();
		if(ret.isSucesso()){
			ret.setSucesso(true);
			ret.setMensagem("Inclusao na tabela "+ this.tabelaClass.getTabelaNome()+" realizada com sucesso!");
			ret.setAcao(ACAO_PADRAO);
		}else{
			ret.setSucesso(false);
			ret.setMensagem("Inclusao na tabela "+ this.tabelaClass.getTabelaNome()+" falhou! \n Erro:"+ret.getMensagem());
			ret.setAcao(NOVO);
		}
		return ret;
	}



	protected TABELA tabelaClass;
	

/*	@Override
	protected List<String> initAcoesValidas() {
		super.initAcoesValidas();
		this.acoesValidas.add(NOVO);
		this.acoesValidas.add(EDITAR);
		this.acoesValidas.add(INCLUIR);
		this.acoesValidas.add(ALTERAR);
		this.acoesValidas.add(APAGAR);
		this.acoesValidas.add(LISTAR_TODOS);
		this.acoesValidas.add(LOCALIZAR);
	}	
	*/


	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodosUtil() {
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodos = super.getAcaoMetodosUtil();
		acaoMetodos.put(NOVO, null);//a��o NOVO n�o tem processamento no negocio somente visao
		acaoMetodos.put(EDITAR,null);//a��o EDITAR n�o tem processamento no negocio somente visao
		acaoMetodos.put(INCLUIR, this::acaoIncluir);//acao incluir tem processamento no negocio
		acaoMetodos.put(ALTERAR, this::acaoAlterar);//acao alterar tem processamento no negocio
		acaoMetodos.put(APAGAR,this::acaoRemover);//acao apagar tem processamento no negocio
		acaoMetodos.put(LISTAR_TODOS, null);//acao LISTAR_TODOS nao tem processamento no negocio somente visao
		acaoMetodos.put(PROCURAR,null);
		return acaoMetodos;
	}


	/**
	 * retorna uma lista de valores com os valores correspondentes aos campos 
	 * da Tabela, pois na lista de Valores Pode ter mais informa��es que a lista de valores
	 * @return
	 *///getObjectValuesList
	protected List<Object> getTabelaCamposValoresDasVariaveis(){
		return this.getTabelaCamposValoresDasVariaveis(this.tabelaClass);
		/*List<String> columns = this.tabelaClass.getCamposNome();
		List<Object> columnsValues = new ArrayList<Object>();
		for(int i=0;i<columns.size();i++){
			Object valor =  this.variaveis.get(columns.get(i));
			columnsValues.add(valor);
		}
		
		return columnsValues;*/
	}
	
	public List<Object> getTabelaCamposValoresDasVariaveis(Tabela tabela){
		if(tabela == null) return null;
		
		List<String> columns = tabela.getCamposNome();
		List<Object> columnsValues = new ArrayList<Object>();
		for(int i=0;i<columns.size();i++){
			Object valor =  this.variaveis.get(columns.get(i));
			columnsValues.add(valor);
		}
		
		return columnsValues;
	}
	
	
	@Override
	public Retorno incluir() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			return ret;
		}
		return this.incluir(this.tabelaClass);
	}


	public Retorno preencherTabelaComVariaveis() {
		this.tabelaClass.limparColunas();;
		Retorno ret = this.tabelaClass.setCamposValorUtil(this.getTabelaCamposValoresDasVariaveis());
		return ret;
	}

	@Override
	public Retorno remover() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			return ret;
		}		
		return this.remover(this.tabelaClass);
	}

	@Override
	public Retorno alterar() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			return ret;
		}		
		return this.alterar(this.tabelaClass);
	}
	

	@Override
	public TABELA getObjetoPreenchido() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			throw new RuntimeException("Erro preenchendo dados da vis�o no modelo:"+ret.getMensagem());
		}
		return this.tabelaClass;
	}


	@Override
	public TABELA editar() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			throw new RuntimeException("Erro Editar("+this.getClass().getSimpleName()+") mensagem:"+ret.getMensagem());
		}			
		return this.editar(this.tabelaClass);
	}
	
	@Override
	public List<TABELA> procurar() {
		Retorno ret = preencherTabelaComVariaveis();
		if(!ret.isSucesso()) {
			throw new RuntimeException("Erro Editar("+this.getClass().getSimpleName()+") mensagem:"+ret.getMensagem());
		}				
		return this.procurar(this.tabelaClass);
	}
	
	public <T extends Tabela<?>> T getDadosExtrangeiro(T tab){
		if(tab==null) return null;
		return DAOGeneric.getIntancia().getObjeto(tab);
	}
	public <T extends Tabela<?>> List<T> procurarTodos(T tab){
		if(tab==null) return null;
		return DAOGeneric.getIntancia().procurar(tab);
	}


}
