package controle;

import java.util.HashMap;

import interfaces.IReferenciaAcaoNegocio;
import modelo.TabelaTeste;

public class TesteControle extends CrudControle<TabelaTeste,Integer> {

	@Override
	public TabelaTeste getNovoObjeto() {
		return new TabelaTeste();
	}

	@Override
	public String getCasoDeUso() {
		return "ManterFake";
	}

	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() {
		return null;
	}

}
