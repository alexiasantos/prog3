package controle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import interfaces.IReferenciaAcaoNegocio;
import interfaces.IControleNegocio;
import util.Retorno;

public abstract class Controle implements IControleNegocio {

	public static final String ACAO_PADRAO = "index";
	protected HashMap<String, Object> variaveis;
	protected List<String> acoesValidas;
	protected String caminhoAplicacao;
	
	
	public Controle(){
		this.variaveis = new HashMap();
		this.initAcoesValidas();
		this.initCaminhoAplicacao();
	}
	private void initCaminhoAplicacao() {
		try {
			this.caminhoAplicacao = new java.io.File( "." ).getCanonicalPath();
		} catch (IOException e) {
			System.out.println("Erro ao obter Caminho Aplica��o");
			e.printStackTrace();
			this.caminhoAplicacao = "c:";
			
		}
	}
	
	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodosUtil() {
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodos = new HashMap<>();
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodosExtras = this.getAcaoMetodos();
		if(acaoMetodosExtras!=null) {
			acaoMetodos.putAll(acaoMetodosExtras);
		}
		acaoMetodos.put(ACAO_PADRAO, this::_acaoPadrao);
		return acaoMetodos;
	}
	public Retorno _acaoPadrao(String acao) {
		Retorno ret = null;
		if(!this.acaoExiste(acao)){			
			ret = new Retorno(false, "Nenhuma a��o implementada!",acao);
		}else{
			ret = new Retorno(true, null,acao);//A��o Existe!
		}
		return ret;
	}
	
	/**
	 * Deve retornar a lista de acoes suportadas pelo controlador associado ao metodo que dever� ser envocado
	 * utiliza referecia para metodos (http://tecnopode.blogspot.com.br/2015/09/referencias-para-metodos-e-seu-uso.html
	 * https://docs.oracle.com/javase/tutorial/java/javaOO/methodreferences.html
	 * Exemplo:
	 * <pre>
	 *  HashMap&lt;String, IAcaoNegocioFunctional&gt; acaoMetodos = new HashMap<>();
	 *  acaoMetodos.put("nomeAcao",this::acaoNomeAcao);//para a��es que tem processamento na camada de controle(negocio)
	 *  acaoMetodos.put("nomeAcao2",null);//acao que n�o tem processamento na camada de controle
	 *  
	 *  return acaoMetodos;
	 * </pre>
	 * O metodo de a��o deve ter a assinatura public Retorno acaoNomeAcao(String acao)
	 * @return
	 */
	public abstract HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() ;
	
	protected List<String> initAcoesValidas() {
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodos = this.getAcaoMetodosUtil();
		
		this.acoesValidas = new ArrayList<>();
		
		Iterator<String> iteratorAcaoMetodos = acaoMetodos.keySet().iterator();
		while(iteratorAcaoMetodos.hasNext()) {
			String acaoNome = iteratorAcaoMetodos.next();
			this.acoesValidas.add(acaoNome);
		}
		return this.acoesValidas;
	}	
	@Override
	public boolean acaoExiste(String acao) {
		if(getListaDeAcoesValidas().contains(acao)) {
			return true;
		}
		return false;
	}

	
	@Override
	public void setVariaveis(HashMap<String, Object> variables) {
		this.variaveis.putAll(variables);
	}
	
	@Override
	public void limparVariaveis() {
		this.variaveis.clear();
	}

	@Override
	public HashMap<String, Object> getVariaveis() {
		return this.variaveis;
	}
	@Override
	public Retorno executar(String acao) {
		Retorno ret = this._acaoPadrao(acao);
		if(!ret.isSucesso()) {
			return ret;
		}
		ret = this.processarAcaoDeNegocio(acao);
		return ret;
	}
	
	protected Retorno processarAcaoDeNegocio(String acao) {
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodos = this.getAcaoMetodosUtil();
		IReferenciaAcaoNegocio acaoMetodo = acaoMetodos.get(acao); 
		if (acaoMetodo == null) {
			acaoMetodo = acaoMetodos.get(ACAO_PADRAO);
		}
		Retorno ret = acaoMetodo.executar(acao);
		return ret;

	}
	@Override
	public List<String> getListaDeAcoesValidas() {
		return this.acoesValidas;
	}
	
	@Override
	public void configurarCaminhoAplicacao(String caminho) {
		this.caminhoAplicacao = caminho;		
	}
	@Override
	public String getCaminhoAplicacao() {
		return this.caminhoAplicacao;
	}

}
