package conversores;

import interfaces.IConversor;

public class FloatConversor implements IConversor<Float> {

	@Override
	public Float converter(String valor) {
		if(valor == null || valor.equals("")) return null;
		Float retorno ;
		try{
			retorno = Float.valueOf(valor);
		}catch (NumberFormatException e) {
			throw new RuntimeException("Erro convers�o:"+e.getMessage());
		}
		return retorno;
	}

	@Override
	public String converterBdParaVisao(Float valor) {
		if(valor==null) {
			return "";
		}else {
			return valor.toString();
		}
	}

}
