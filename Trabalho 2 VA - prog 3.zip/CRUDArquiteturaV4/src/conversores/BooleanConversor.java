package conversores;

import interfaces.IConversor;

public class BooleanConversor implements IConversor<Boolean> {
	private static String VALOR_BOOLEAN_TRUE = "true";
	private static String VALOR_BOOLEAN_FALSE = "false";
	
	private String valorVerdadeiro;
	private String valorFalso;
	public BooleanConversor(String verdadeiro, String falso) {
		this.valorVerdadeiro = verdadeiro;
		this.valorFalso = falso;
	}
	public BooleanConversor() {
		this.valorVerdadeiro = "Verdadeiro";
		this.valorFalso = "Falso";
	}
	@Override
	public Boolean converter(String valor) {
		if(valor == null || valor.equals("")) return null;
		Boolean retorno ;
		try{
			if(valor.equalsIgnoreCase(this.valorVerdadeiro) || valor.equalsIgnoreCase(VALOR_BOOLEAN_TRUE)){
				retorno = new Boolean(true);
			}else{
				retorno = new Boolean(false);
			}
		}catch (Exception e) {
			throw new RuntimeException("Erro convers�o:"+e.getMessage());
		}
		return retorno;
	}

	@Override
	public String converterBdParaVisao(Boolean valor) {
		if(valor==null) {
			return "";
		}else {
			if(valor) {
				return this.valorVerdadeiro;
			}else {
				return this.valorFalso;
			}
		}
	}

}
