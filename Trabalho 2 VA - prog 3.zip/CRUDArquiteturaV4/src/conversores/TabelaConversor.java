package conversores;

import interfaces.IConversor;
import interfaces.ITabelaConversor;
import modelo.Tabela;

public class TabelaConversor implements ITabelaConversor<Tabela> {
	private Tabela<?> tabela;
	public TabelaConversor(Tabela<?> tab) {
		this.tabela = tab;
	}
	public Tabela getTabela() {
		return this.tabela;
	}
	
	@Override
	public Tabela converter(String valor) {
		if(valor==null) return null;
		Tabela t = this.getTabela().getNovoObjeto();
		if(valor.equals("")) return t;
		
		Object pkValue = Integer.valueOf(valor);
		
		int indicePk = this.getTabela().getColunaPK();
		IConversor conv = (IConversor) this.getTabela().getCamposConversorUtil().get(indicePk);
		Object pkValor = conv.converter(valor);
		t.setPk(pkValor);
		t = t.getDadosExtrangeiro(t);	
		return t;
	}

	@Override
	public String converterBdParaVisao(Tabela valor) {
		if(valor==null) {
			return "";
		}
		return valor.toString();//valor.getTipo()
	}

}
