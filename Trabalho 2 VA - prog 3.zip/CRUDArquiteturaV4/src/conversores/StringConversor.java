package conversores;

import interfaces.IConversor;

public class StringConversor implements IConversor<String> {

	@Override
	public String converter(String valor) {
		return valor;
	}

	@Override
	public String converterBdParaVisao(String valor) {
		if(valor==null) {
			return "";
		}else {
			return valor;
		}
	}

}
