package interfaces;

public interface ITabelaConversor<TIPO> extends IConversor<TIPO> {
	public TIPO getTabela();
}
