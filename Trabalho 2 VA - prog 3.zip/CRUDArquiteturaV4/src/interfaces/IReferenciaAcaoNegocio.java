package interfaces;

import util.Retorno;

public interface IReferenciaAcaoNegocio {
	Retorno executar(String acao);
}
