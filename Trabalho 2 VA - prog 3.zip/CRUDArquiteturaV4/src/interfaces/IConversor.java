package interfaces;

public interface IConversor<TIPO> {
	public TIPO converter(String valor);
	public String converterBdParaVisao(TIPO valor);
}
