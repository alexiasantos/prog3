package util;

public class Retorno {
	private boolean sucesso;
	private String mensagem;
	private String acao;
	
	public Retorno(boolean sucesso, String mensagem){
		setSucesso(sucesso);
		setMensagem(mensagem);
		setAcao("execute");
	}
	public Retorno(boolean sucesso, String mensagem, String acao){
		setSucesso(sucesso);
		setMensagem(mensagem);
		setAcao(acao);
	}
	
	public boolean isSucesso() {
		return sucesso;
	}
	public String getMensagem() {
		if(this.mensagem == null) this.mensagem = "";
		return mensagem;
	}
	public void setSucesso(boolean sucesso) {
		this.sucesso = sucesso;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	@Override
	public String toString() {
		return "Retorno [sucesso=" + sucesso + ", mensagem=" + mensagem + ", acao=" + acao + "]";
	}

	public void copiar(Retorno ret) {
		this.setAcao(ret.getAcao());
		this.setMensagem(ret.getMensagem());
		this.setSucesso(ret.isSucesso());
	}
	
}
