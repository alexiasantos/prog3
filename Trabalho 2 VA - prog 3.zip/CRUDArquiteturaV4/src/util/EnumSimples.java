package util;

public enum EnumSimples {
	VALOR1, VALOR2, VALOR3, VALOR4;
}
