package view.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import biz.source_code.miniTemplator.MiniTemplator;
import controle.CrudControle;
import interfaces.IControleNegocio;
import interfaces.IConversor;
import interfaces.ICrudControleNegocio;
import interfaces.IReferenciaVisaoAcao;
import interfaces.ITabelaConversor;
import modelo.Tabela;

public abstract class VisaoCrudServletControleGenerica  extends VisaoServletControleGenerica{


/*	@Override
	public MiniTemplator executarAcao(HttpServletRequest request, IControleNegocio controle, String acao, Retorno controleRetornoAcao) {
		MiniTemplator t = super.executarAcao(request, controle, acao, controleRetornoAcao);
		
		
		ICrudControlador<Tabela<?>,?> crudController = (ICrudControlador<Tabela<?>,?>)controle;
	
		if(acao.equalsIgnoreCase(CrudControle.LISTAR_TODOS)){
			processaListarTodos(t, crudController);
		}
		if(acao.equalsIgnoreCase(CrudControle.NOVO)){
			//this.mesclarVariaveis(t, crudController);
			processNew(t, crudController);
		}
		if(acao.equalsIgnoreCase(CrudControle.EDITAR)){
			processEdit(t, crudController);
			this.mesclarVariaveis(t, crudController);
		}
		
		return t;
	}*/
	
	public void mesclarMapValores(MiniTemplator t,ICrudControleNegocio<Tabela<?>,?> crudControleNegocio, HashMap<String,Object> map) {
		this.mesclarMapValores(t,crudControleNegocio, map,null);
	}

	@SuppressWarnings("rawtypes")
	public void mesclarMapValores(MiniTemplator t, ICrudControleNegocio<Tabela<?>,?> crudControleNegocio, HashMap<String,Object> map, String prefixo) {
		prefixo=prefixo==null||prefixo.equals("")?"":prefixo+".";
		Iterator<Entry<String, Object>> iterator = map.entrySet().iterator();
		while(iterator.hasNext()){
			Entry<String, Object> coluna = iterator.next();
			String nomeColuna = prefixo+coluna.getKey();
			Object valorOriginal = coluna.getValue();
			String valorColuna = valorOriginal==null?"":valorOriginal.toString();
			t.setVariable(nomeColuna, valorColuna,true);
			//para ser utilizado com campos select
			//variavel no padra�o. prefixo.campo.valor.selected
			String nomeVariavelSelected = nomeColuna+"."+valorColuna+".selected";
			System.out.println("nomeVariavelSelected:"+nomeVariavelSelected);
			t.setVariable(nomeVariavelSelected,"selected",true);
			mesclarMapEstrangeiro(t, crudControleNegocio,prefixo, nomeColuna,valorOriginal, valorColuna);
			
			
			
		}
	}

	@SuppressWarnings("rawtypes")
	public void mesclarMapEstrangeiro(MiniTemplator t,ICrudControleNegocio<Tabela<?>,?> crudControleNegocio, String prefixo,String nomeColuna, Object valorOriginal, String valorColuna) {
		Tabela tabelaPrincipal = crudControleNegocio.getNovoObjeto();
		int indColuna;
		try{
			indColuna = tabelaPrincipal.getCampoIndice(nomeColuna);
		}catch (Exception e) {
			return;
		}
		System.out.println("mesclarMapEstrangeira:indcoluna:"+indColuna+" nomecoluna:"+nomeColuna);
		IConversor conv = (IConversor)tabelaPrincipal.getCamposConversorUtil().get(indColuna);
		
		if(conv instanceof ITabelaConversor) {
			ITabelaConversor convTabela = (ITabelaConversor)conv;
			Tabela tabelaEstrangeira = (Tabela)convTabela.getTabela();
			String tabelaEstrangeiraNome = tabelaEstrangeira.getTabelaNome();
			String prefixoOriginal = prefixo+(prefixo.equals("")?"":".")+tabelaEstrangeiraNome;
			if(valorOriginal==null || valorOriginal.equals("")) {
				valorOriginal = tabelaEstrangeira;
			}
			Tabela valorOriginalTabela = (Tabela)valorOriginal;
			HashMap<String,Object> mapOrignal = this.getMapValoresFromTabela(valorOriginalTabela) ;
			this.mesclarMapValores(t,crudControleNegocio, mapOrignal, prefixoOriginal);
			t.setVariable(tabelaEstrangeiraNome, valorColuna,true);		
		}
				

	}
	
	private void processaListarTodos(MiniTemplator t,IControleNegocio controleNegocio) {
		ICrudControleNegocio<Tabela<?>,?> crudControleNegocio = (ICrudControleNegocio<Tabela<?>,?>)controleNegocio;
		List<Tabela<?>> listAllObject = crudControleNegocio.listar();	
		this.mesclarListarOuProcurar(t, crudControleNegocio, listAllObject);
	}
	private void processaProcurar(MiniTemplator t,IControleNegocio controleNegocio) {
		ICrudControleNegocio<Tabela<?>,?> crudControleNegocio = (ICrudControleNegocio<Tabela<?>,?>)controleNegocio;
		List<Tabela<?>> listAllObject = crudControleNegocio.procurar();	
		this.mesclarListarOuProcurar(t, crudControleNegocio, listAllObject);
		
		Tabela table = crudControleNegocio.getObjetoPreenchido();
		
		this.processaTodasTabelaEstrangeira(t, table,crudControleNegocio);
	}
	public void mesclarListarOuProcurar(MiniTemplator t,ICrudControleNegocio<Tabela<?>,?> crudControleNegocio,List<Tabela<?>> listAllObject) {	
		for(Tabela<?> tabela: listAllObject) {
			this.mesclarMapValores(t,crudControleNegocio, this.getMapValoresFromTabela(tabela));
			t.setVariable("acaoEditar", CrudControle.EDITAR,true);
			t.setVariable("acaoApagar", CrudControle.APAGAR,true);
			
			t.addBlock(crudControleNegocio.getCasoDeUso(),true);
		}
		this.mesclarVariaveis(t, crudControleNegocio);
	}

	protected void processNew(MiniTemplator t,
			IControleNegocio controleNegocio) {
		
		ICrudControleNegocio<Tabela<?>,?> crudControleNegocio = (ICrudControleNegocio<Tabela<?>,?>)controleNegocio;
		
		this.mesclarVariaveis(t, controleNegocio);
		this.processaTodasTabelaEstrangeira(t, crudControleNegocio.getNovoObjeto(),crudControleNegocio);
		
		t.setVariable("acao", CrudControle.INCLUIR,true);
		
		if(!crudControleNegocio.getNovoObjeto().getUsarPkNaInsercao()) {
		//adicionado para tornar o campo da pk readonly utilizar a variavel pkname_readonly quando a chave primaria n�o � usada na inser�ao
			String nomeVariavel = crudControleNegocio.getNovoObjeto().getTabelaPKNomeUtil()+"_readonly";
			t.setVariable(nomeVariavel, "readonly",true);
			System.out.println("processNew: nomeVariavelPKReadonly: "+nomeVariavel);
		}
		
	}
	
	private void processEdit(MiniTemplator t,IControleNegocio controleNegocio) {
		
		ICrudControleNegocio<Tabela<?>,?> crudControleNegocio = (ICrudControleNegocio<Tabela<?>,?>)controleNegocio;
		t.setVariable("acao", CrudControle.ALTERAR,true);
		try {
			Tabela<?> tabela = crudControleNegocio.editar();
			this.processarTabela(t, tabela,crudControleNegocio);
			
			this.processaTodasTabelaEstrangeira(t, tabela,crudControleNegocio);
			
			
			//adicionado para tornar o campo da pk readonly utilizar a variavel pkname_readonly
			t.setVariable(crudControleNegocio.getNovoObjeto().getTabelaPKNomeUtil()+"_readonly", "readonly",true);
		}catch(Exception e) {
			t.setVariable("message", e.getMessage(),true);
			e.printStackTrace();
			//TODO verificar problema de n�o exibir mensagem de vis�o
		}
		
		this.mesclarVariaveis(t, crudControleNegocio);
		
	}

	public void processaTodasTabelaEstrangeira(MiniTemplator t, Tabela<?> tabelaPrincipal, ICrudControleNegocio<Tabela<?>, ?> crudControleNegocio) {
		List<IConversor> lista  = tabelaPrincipal.getCamposConversorUtil();
		for(int i=0; i<lista.size();i++){
			IConversor conv = lista.get(i);
			if(conv instanceof ITabelaConversor) {
				ITabelaConversor tabConv = (ITabelaConversor) conv;
				Tabela tabelaEstrangeira = (Tabela)tabConv.getTabela();
				String nomeCampo = tabelaPrincipal.getCamposNome().get(i);
				Tabela valorCampoFK = (Tabela)tabelaPrincipal.getCampoValor(nomeCampo);
				
				List<Tabela> listaEstrangeiro = crudControleNegocio.procurarTodos(tabelaEstrangeira);
				
				processarTabelaEstrangeira(t, crudControleNegocio, valorCampoFK, listaEstrangeiro);
			}
		}
	}

	public void processarTabelaEstrangeira(MiniTemplator t, ICrudControleNegocio<Tabela<?>, ?> crudControleNegocio,
			Tabela valorCampoFK, List<Tabela> listaEstrangeiro) {
		if(listaEstrangeiro == null || listaEstrangeiro.isEmpty()) {
			return;
		}
		String tabelaEstrangeiraNome = listaEstrangeiro.get(0).getTabelaNome();
		String prefixoEstrangeiro = "estrangeiro."+tabelaEstrangeiraNome;
		String nomeBlocoEstrangeiro = "estrangeiro_"+tabelaEstrangeiraNome;
		for(Tabela linha:listaEstrangeiro) {
			this.mesclarMapValores(t, crudControleNegocio, this.getMapValoresFromTabela(linha),prefixoEstrangeiro);
			String nome_selected_variable = "estrangeiro."+tabelaEstrangeiraNome+".selected";
			if(valorCampoFK!=null && 
					linha.getPk().equals(valorCampoFK.getPk())) {						
				t.setVariable(nome_selected_variable, "selected");
			}else {
				t.setVariable(nome_selected_variable, "");
			}
			t.addBlock(nomeBlocoEstrangeiro);
		}
	}
	
	private void processarTabela(MiniTemplator t,Tabela<?> table, ICrudControleNegocio<Tabela<?>, ?> crudControleNegocio){
		
		this.mesclarMapValores(t,crudControleNegocio, this.getMapValoresFromTabela(table),table.getTabelaNome().toLowerCase());
		
		/*List<String> colNames  = table.getCamposNome();
		List<Object> colValues = table.getCamposValorUtil();
		
		for(int i=0;i < colNames.size();i++){
			t.setVariable(table.getTabelaNome().toLowerCase()+"."+colNames.get(i),colValues.get(i).toString(),true);			
		}*/
	}

	public HashMap<String, Object> getMapValoresFromTabela(Tabela<?> tabela){
		HashMap<String, Object> mapValores = new HashMap<>();
		List<String> camposNomes = tabela.getCamposNome();
		List<Object> camposValores = tabela.getCamposValorUtil();
		List<IConversor> listConversor = tabela.getCamposConversorUtil();
		
		for (int i = 0; i < camposNomes.size(); i++) {
			String nome = camposNomes.get(i);
			Object valor = camposValores.get(i);
			String valorTela = listConversor.get(i).converterBdParaVisao(valor);
			mapValores.put(nome+"_tela", valorTela);
			mapValores.put(nome, valor);
		}
		return mapValores;
	}

/*	public List<HashMap<String, Object>> getMapValoresFromTabela(List<Tabela<?>> tab){
		List<HashMap<String, Object>> lista = new ArrayList<HashMap<String,Object>>();
		
		if(tab.size()==0) return lista;
		
		for (Tabela<?> tabela : tab) {
			HashMap<String, Object> listValores = this.getMapValoresFromTabela(tabela);	
			lista.add(listValores);
		}
		
		return lista;
	}
	*/
	protected void mesclarVariaveis(MiniTemplator t,IControleNegocio controle){
		ICrudControleNegocio<Tabela<?>,?> crudController = (ICrudControleNegocio<Tabela<?>,?>)controle;
		
		Tabela<?> tabela = crudController.getNovoObjeto();
		String prefixo = tabela.getTabelaNome().toLowerCase();
		
		this.mesclarVariaveis(t,crudController,prefixo);		
	}


	
	//TODO verificar para remover
	@Override
	public String getCasoDeUso() {
		return "crud";
	}
	
	@Override
	public HashMap<String, IReferenciaVisaoAcao> getVisaoAcaoMetodosUtil() {
		HashMap<String, IReferenciaVisaoAcao> list = super.getVisaoAcaoMetodosUtil();
		list.put(CrudControle.LISTAR_TODOS, this::processaListarTodos);
		list.put(CrudControle.NOVO,this::processNew);
		list.put(CrudControle.EDITAR, this::processEdit);
		list.put(CrudControle.PROCURAR, this::processaProcurar);
		return list;
	}

}