package view.controller;

import java.util.HashMap;

import interfaces.IReferenciaVisaoAcao;

public final class VisaoServletControle extends VisaoServletControleGenerica {
	@Override
	public HashMap<String, IReferenciaVisaoAcao> getVisaoAcaoMetodos() {
		return null;
	}


}
