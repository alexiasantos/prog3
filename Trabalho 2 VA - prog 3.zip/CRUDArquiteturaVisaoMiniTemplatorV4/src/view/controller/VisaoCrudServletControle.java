package view.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import biz.source_code.miniTemplator.MiniTemplator;
import controle.CrudControle;
import interfaces.IControleNegocio;
import interfaces.ICrudControleNegocio;
import interfaces.IReferenciaVisaoAcao;
import interfaces.IVisaoControle;
import modelo.Tabela;
import util.Retorno;

public final class VisaoCrudServletControle extends VisaoCrudServletControleGenerica {
	@Override
	public HashMap<String, IReferenciaVisaoAcao> getVisaoAcaoMetodos() {
		// TODO Auto-generated method stub
		return null;
	}

}
