package controle;

import java.io.File;
import java.util.HashMap;

import interfaces.IReferenciaAcaoNegocio;
import util.PaginaUtilitario;

public class PaginaControle extends Controle {
	private String casoDeUsoLocal;

	public void setCasoDeUso(String casoDeUso) {
		this.casoDeUsoLocal = casoDeUso;
		
	}
	@Override
	public String getCasoDeUso() {
		if(this.casoDeUsoLocal==null) {
			this.casoDeUsoLocal="pagina";
		}
		return this.casoDeUsoLocal;
	}
	

/*	@Override
	public boolean acaoExiste(String acao) {
		//caractere separador de diret�rios
		String sp = System.getProperty("file.separator");
		//metodo utilizado para evitar acompalmento e depend�ncia entre as classes ServletControle
		String caminho = PaginaUtilitario.getCaminhoPaginaCasoDeUso(this.getCaminhoAplicacao(), this.getCasoDeUso(), acao);
		File file = new File(caminho);
		if(file.exists()) {
			return true;
		}else {		
			return false;
		}
	}*/
	
	//foi necess�rio sobrescrever para iniciar as a��es, pois quando o controlador � criado n�o foi definido o caminho da aplica��o
	@Override
	public void configurarCaminhoAplicacao(String caminho) {
		
		super.configurarCaminhoAplicacao(caminho);
		this.initAcoesValidas();
	}
	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() {
		
			String diretorio = PaginaUtilitario.getCaminhoDiretorioCasoDeUso(this.getCaminhoAplicacao(),this.getCasoDeUso());
		
		File file = new File(diretorio);
		if(!file.exists()) {
			return null;
		}
		
		HashMap<String, IReferenciaAcaoNegocio> acaoMetodos = new HashMap<>();
		File afile[] = file.listFiles();
		int i = 0;
		for (int j = afile.length; i < j; i++) {
			File arquivos = afile[i];
			String arquivo = arquivos.getName().replaceAll(".html", "");
			acaoMetodos.put(arquivo,null);
			//System.out.println(arquivo);
		}
		
		return acaoMetodos;
	}
}
