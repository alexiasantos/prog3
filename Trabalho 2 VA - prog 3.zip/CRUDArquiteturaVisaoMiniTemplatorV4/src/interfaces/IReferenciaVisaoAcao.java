package interfaces;

import biz.source_code.miniTemplator.MiniTemplator;

public interface IReferenciaVisaoAcao {
        void processar(MiniTemplator t,
    			IControleNegocio controleNegocio);
}
