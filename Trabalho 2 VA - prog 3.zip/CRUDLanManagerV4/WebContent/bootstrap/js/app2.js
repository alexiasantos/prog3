function checkEmail () {
        var frm = document.forms[0];            
    	var name = frm.name.value;
    	var email = frm.email.value;
    	var senha = frm.senha.value;
    	
    	var count = 0;
    	var flagError = false;
    	var error="";
    	var regex = /^(?=(?:.*?[A-Z]){1})(?=(?:.*?[0-9]){1})(?=(?:.*?[!@#$%*()_+^&}{:;?.]){1})(?!.*\s)[0-9a-zA-Z!@#$%;*(){}_+^&]*$/; 
    	
    	
    	if (senha.length < 8||senha.length > 8) {
    		error += "O campo Senha deve ter 8 carateres mínimos.";
    		count = count + 1
    		flagError = true;
    		
    	}else if(!regex.exec(senha)){
    	error += "A senha deve conter no mínimo 1 caracteres em maiúsculo, 1 número e 1 caractere especial!.";
    		count = count + 1
    		flagError = true;
    	}
    	
    	if (count > 0 ){
              alert("Os seguintes erros foram encontrados:\n" + error);

              return;

        
    	}

    	if (!flagError) {
    		var illegalChars = /(@.*@)|(@\.)|(@\-)|(@_)(\.@)|(\-@)|(\.\.)|(^\.)|(\.$)|(\.\-)|(\._)|(\-\.)|(_\.)|(^_)|(_$)|(_\-)|(\-\-)|(^\-)|(\-$)|(\-_)/;
    		if (email.match(illegalChars)) {
    			error += "O endereço de e-mail contém caracteres inválidos.";
    			count = count + 1
    			flagError = true;
    		}
    	}

    	if (!flagError) {
    		var emailFilter = /^\S+\@(\[?)[a-zA-Z0-9_\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    		if (!(emailFilter.test(email))) { 
    			error += "O endereço de e-mail não está em um formato válido.";
    			count = count + 1
    			flagError = true;
    		}
    	}

    	if (!flagError) {
    		var emailFilter = /^([a-zA-Z0-9\@_\-\.\+]+)$/;
    		if (!(emailFilter.test(email))) { 
    			error += "O endereço de e-mail não está em um formato válido.";
    			count = count + 1
    			flagError = true;
    		}
    	}
    	if (!flagError) {
    		flagError = false;
            frm.submit()
    		}

    	if (flagError) {
    		window.alert(error);
    	}

    	return !flagError;
    }

				