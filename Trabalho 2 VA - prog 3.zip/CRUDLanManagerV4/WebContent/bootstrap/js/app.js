
var btnSignin = document.querySelector("#signin");
var btnSignup = document.querySelector("#signup");

var body = document.querySelector("body");


btnSignin.addEventListener("click", function () {
   body.className = "sign-in-js"; 
});

btnSignup.addEventListener("click", function () {
	
    body.className = "sign-up-js";
})


	function getCookie(name) {
	 			 var value = "; " + document.cookie;
	  			var parts = value.split("; " + name + "=");
	  			if (parts.length == 2){
		 		 return parts.pop().split(";").shift();
	  				}
				}
								
				
	function del(codigo) {  
    if (confirm('Excluir a categoria?')) {  
        location.href = 'sistema?casoDeUso=manterUsuarios&acao=apagar&iduser='+codigo;
        alert("usuario não existe mais, redirecionamento automático");
        location.href="index.html";
    }
}






