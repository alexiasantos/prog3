package view.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import controle.ManterFilme;
import controle.ManterProdutora;
import controle.ManterUsuarios;
import interfaces.IControleNegocio;
import interfaces.IVisaoControle;

@SuppressWarnings("serial")
public class ViewServlet extends ServletControle {

	@Override
	public HashMap<String, IVisaoControle> configurarControladoresDeVisao() {
		HashMap<String,IVisaoControle> conf = new HashMap<>(); 
		conf.put("sobre", new VisaoServletControle());//controlador de caso de uso generico para paginas sem controaldor 
		conf.put("manterFilme", new VisaoCrudServletControle());
		conf.put("manterProdutora", new VisaoCrudServletControle());
		conf.put("manterUsuarios", new VisaoCrudServletControle());
		return conf;
	}

	@Override
	public List<IControleNegocio> configurarControladores() {
		List<IControleNegocio> conf = new ArrayList<>();
		conf.add(new ManterFilme());
		conf.add(new ManterProdutora());
		conf.add(new ManterUsuarios());
		return conf;
	}
	

}
