package controle;

import java.util.HashMap;

import interfaces.IReferenciaAcaoNegocio;
import model.Produtora;

public class ManterProdutora extends CrudControle<Produtora,Integer> {


	@Override
	public String getCasoDeUso() {
		return "manterProdutora";
	}

	@Override
	public Produtora getNovoObjeto() {
		return new Produtora();
	}

	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() {
		return null;
	}
	
	
}
