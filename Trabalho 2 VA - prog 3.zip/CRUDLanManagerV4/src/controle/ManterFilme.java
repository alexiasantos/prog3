package controle;

import java.util.HashMap;

import interfaces.IReferenciaAcaoNegocio;
import model.Filme;

public class ManterFilme extends CrudControle<Filme, Integer> {

	@Override
	public String getCasoDeUso() {
		return "manterFilme";
	}

	@Override
	public Filme getNovoObjeto() {
		return new Filme();
	}

	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() {
		return null;
	}

}
