package controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import interfaces.IReferenciaAcaoNegocio;
import model.Usuarios;
import util.Retorno;

public class ManterUsuarios extends CrudControle<Usuarios,Integer> {

	@Override
	public String getCasoDeUso() {
		return "manterUsuarios";
	}

	@Override
	public Usuarios getNovoObjeto() {
		Usuarios U = new Usuarios();
		List<Object> senha = U.getCamposValor();
		System.out.println(senha);
		return new Usuarios();
	}

	@Override
	public HashMap<String, IReferenciaAcaoNegocio> getAcaoMetodos() {
		return null;
	}
	
	
	
	
	
	// regras de neg�cio

	@Override
	protected Retorno acaoIncluir(String Acao) {
		Retorno ret = new Retorno(true,"");
		
		ret = validaEmail( Acao);
		if(!ret.isSucesso()) {
			return ret;
		}
		ret = validaSenha();
		if(!ret.isSucesso()) {
			return ret;
		}
		
	
		return super.acaoIncluir(Acao);
	}
	protected Retorno acaoAlterar(String Acao) {
		Retorno ret = new Retorno(true,"");
		
		ret = validaEmail( Acao);
		if(!ret.isSucesso()) {
			return ret;
		}
		ret = validaSenha();
		if(!ret.isSucesso()) {
			return ret;
		}
		
	
		return super.acaoAlterar(Acao);
	}

	private Retorno validaEmail(String Acao) {
		String email = (String) this.getVariaveis().get("email");
		
		Retorno ret = new Retorno(true,"");
		
		if(email.equals("")) {
			ret.setSucesso(false);
			ret.setMensagem("Email n�o pode ficar vazio");
			ret.setAcao(NOVO);
			return ret;
			
		}
		
		 boolean isEmailIdValid = false; 
		 if (email != null && email.length() > 0) { 
			 String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$"; 
			 Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE); 
			 Matcher matcher = pattern.matcher(email); 
			 if (matcher.matches()) { 
				 isEmailIdValid = true; 
			 } 
		 }
	 	if(isEmailIdValid==false) {
	 		ret.setSucesso(false);
			ret.setMensagem("Email inv�lido");
			ret.setAcao(NOVO);
			return ret;
	 	}
	 	if(Acao=="Incluir") {
	 	Usuarios usuario = new Usuarios();
	 	usuario.setEmail(email);
	 	List<Usuarios> procurar2 = this.dao.procurar(usuario);
	 	if(procurar2.size()>0) {
	 		ret.setSucesso(false);
			ret.setMensagem("Email existente na nossa base de dados");
			ret.setAcao(NOVO);
			return ret;
		 		
		 }
	 	}
		return ret;
	}
	
	

	@SuppressWarnings("unused")
	private Retorno validaSenha() {
		String senha = (String) this.getVariaveis().get("senha");
		boolean achouNumero = false;
	    boolean achouMaiuscula = false;
	    boolean achouMinuscula = false;
	    boolean achouSimbolo = false;
		Retorno ret = new Retorno(true,"");
		if(senha.equals("")) {
			ret.setSucesso(false);
			ret.setMensagem("Senha n�o pode ficar vazia");
			ret.setAcao(NOVO);
			return ret;
			
		}	else if(senha.length()>8) {
			ret.setSucesso(false);
			ret.setMensagem("Senha contem mais de 8 caracteres");
			ret.setAcao(NOVO);
			return ret;
		}else if(senha.length()<8){
			ret.setSucesso(false);
			ret.setMensagem("Senha contem menos de 8 caracteres");
			ret.setAcao(NOVO);
			return ret;
		}
		
	    for (char c : senha.toCharArray()) {
	         if (c >= '0' && c <= '9') {
	             achouNumero = true;
	         } else if (c >= 'A' && c <= 'Z') {
	             achouMaiuscula = true;
	         } else if (c >= 'a' && c <= 'z') {
	             achouMinuscula = true;
	         } else {
	             achouSimbolo = true;
	         }
	    }
		if(achouNumero==false) {
			ret.setSucesso(false);
			ret.setMensagem("Senha deve ter pelo menos um numero");
			ret.setAcao(NOVO);
			return ret;
		}else if(achouMaiuscula==false) {
			ret.setSucesso(false);
			ret.setMensagem("Senha deve ter pelo menos uma letra maiuscula");
			ret.setAcao(NOVO);
			return ret;
		}else if(achouMinuscula==false) {
			ret.setSucesso(false);
			ret.setMensagem("Senha deve ter pelo menos uma letra min�scula");
			ret.setAcao(NOVO);
			return ret;
		}else if(achouSimbolo==false) {
			ret.setSucesso(false);
			ret.setMensagem("Senha deve ter pelo menos um Simbolo");
			ret.setAcao(NOVO);
			return ret;
		}
		
		return ret;
		
	}

	
	//sobrescrito para poder mudar a a��o padr�o ap�s a a��o de incluir
	

}
