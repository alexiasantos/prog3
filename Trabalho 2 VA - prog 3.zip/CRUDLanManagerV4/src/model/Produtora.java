package model;

import java.util.ArrayList;
import java.util.List;

import conversores.IntegerConversor;
import conversores.StringConversor;
import interfaces.IConversor;
import modelo.Tabela;
import util.Retorno;

public class Produtora extends Tabela<Integer> {

	private String produtora;
	
	public String getprodutora() {
		return produtora;
	}

	public void setprodutora(String produtora) {
		this.produtora = produtora;
	}
	
	// metodos abstratos implementaos
	 
	
	@Override
	public String getTabelaNome() {
		return "produtora";
	}
	
	@Override
	public String getTabelaPKNome() {		
		return "idprodutora";
	}	

	@Override
	public List<String> getCamposNome(){
		ArrayList<String> listNomes = new ArrayList<>();
		listNomes.add("idprodutora");
		listNomes.add("produtora");
		return listNomes ;
	}

	@Override
	protected Retorno setCamposValor(List<Object> list) {
		Retorno ret = new Retorno(true, "OK");
		try{
			this.setPk((Integer) list.get(0));
			this.setprodutora((String) list.get(1) );
 
		}catch(Exception e){
			ret.setSucesso(false);
			ret.setMensagem("Erro ao configura campos, ERROR:"+e.getMessage());
		}
				
		return ret;
	}

	@Override
	public List<Object> getCamposValor() {
		ArrayList<Object> list = new ArrayList<>();

		list.add(this.getPk());
		list.add(this.getprodutora());

		return list;
	}

	@Override
	public Tabela<?> getNovoObjeto() {
		return new Produtora();
	}
	
	@Override
	public List<IConversor> getCamposConversor() {
		ArrayList<IConversor> listConversor = new ArrayList<>();
		listConversor.add(new IntegerConversor());//pk		
		listConversor.add(new StringConversor());
		return listConversor ;
	}
	@Override
	protected List<String> getCamposObrigatorios() {
		List<String> list = new ArrayList<>();
		list.add("produtora");
		return list;
	}

}
