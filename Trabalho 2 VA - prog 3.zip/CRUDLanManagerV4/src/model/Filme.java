package model;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import conversores.DateConversor;
import conversores.FloatConversor;
import conversores.IntegerConversor;
import conversores.StringConversor;
import conversores.TabelaConversor;
import interfaces.IConversor;
import modelo.Tabela;
import util.Retorno;

public class Filme extends Tabela<Integer> {

	private String 	nome_filme;
	private String 	diretor;
	private String 	genero;
	private String 	descricao;
	private Date anolancamento;
	private Produtora produtora;
	private Float duracao;
	private Integer classificacao;
	private String imagem;
	
	public String getImagem() {
		return imagem;
	}



	public void setImagem(String imagem) {
		this.imagem = imagem;
	}



	@Override
	public String getTabelaPKNome() {
		return "idfilme";
	}

	

	@Override
	public String getTabelaNome() {
		return "filme";
	}

	public String getNome_filme() {
		return nome_filme;
	}



	public void setNome_filme(String nome_filme) {
		this.nome_filme = nome_filme;
	}



	public String getDiretor() {
		return diretor;
	}



	public void setDiretor(String diretor) {
		this.diretor = diretor;
	}



	public String getGenero() {
		return genero;
	}



	public void setGenero(String genero) {
		this.genero = genero;
	}



	public String getDescricao() {
		return descricao;
	}



	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}



	public Date getAnolancamento() {
		return anolancamento;
	}



	public void setAnolancamento(Date anolancamento) {
		this.anolancamento = anolancamento;
	}



	public Produtora getProdutora() {
		return produtora;
	}



	public void setProdutora(Produtora produtora) {
		this.produtora = produtora;
	}



	public Float getDuracao() {
		return duracao;
	}



	public void setDuracao(Float duracao) {
		this.duracao = duracao;
	}



	public Integer getClassificacao() {
		return classificacao;
	}



	public void setClassificacao(Integer classificacao) {
		this.classificacao = classificacao;
	}



	@Override
	public List<String> getCamposNome(){
		ArrayList<String> listNomes = new ArrayList<>();
		listNomes.add("idfilme");
		listNomes.add("nome_filme");
		listNomes.add("diretor");
		listNomes.add("genero");
		listNomes.add("descricao");
		listNomes.add("anolancamento");
		listNomes.add("produtora");
		listNomes.add("duracao");
		listNomes.add("classificacao");
		listNomes.add("imagem");
		return listNomes ;
	}

	@Override
	protected Retorno setCamposValor(List<Object> list) {
		Retorno ret = new Retorno(true, "OK");
		try{
			this.setPk((Integer) list.get(0));
			this.setNome_filme((String) list.get(1));
			this.setDiretor((String) list.get(2));
			this.setGenero((String) list.get(3));
			this.setDescricao((String) list.get(4));
			this.setAnolancamento((Date) list.get(5));
			this.setProdutora((Produtora)list.get(6));
			this.setDuracao((Float) list.get(7));
			this.setClassificacao((Integer) list.get(8));
			this.setImagem((String) list.get(9));
			//tem que tratar para dados estrangeiros
			/*Tipo t = new Tipo();
			t.setPk((Integer)list.get(4));
			t = this.getDadosExtrangeiro(t);			
			this.setTipo(t); */
			 
		}catch(Exception e){
			ret.setSucesso(false);
			ret.setMensagem("Erro ao configura camposo, ERROR:"+e.getMessage());
		}
				
		return ret;
	}
	
	@Override
	public List<Object> getCamposValor() {
		ArrayList<Object> list = new ArrayList<>();

		list.add(this.getPk());
		list.add(this.getNome_filme());
		list.add(this.getDiretor());
		list.add(this.getGenero());
		list.add(this.getDescricao());
		list.add(this.getAnolancamento());
		list.add(this.getProdutora());
		list.add(this.getDuracao());
		list.add(this.getClassificacao());
		list.add(this.getImagem());
		


		return list;
	}
	
//--
	@Override
	public Tabela<?> getNovoObjeto() {
		return new Filme();
	}
	
	@Override
	public List<IConversor> getCamposConversor() {
		ArrayList<IConversor> listConversor = new ArrayList<>();
		listConversor.add(new IntegerConversor());//pk		
		listConversor.add(new StringConversor());//nome_filme
		listConversor.add(new StringConversor());//diretor
		listConversor.add(new StringConversor());//genero
		listConversor.add(new StringConversor());//descricao
		listConversor.add(new DateConversor());//anolancamento
		listConversor.add(new TabelaConversor(new Produtora()));//Tipo(vindo como a pk)
		listConversor.add(new FloatConversor());//duracao
		listConversor.add(new IntegerConversor());//classificacao
		listConversor.add(new StringConversor());//imagem
		return listConversor ;
	}
	

	@Override
	protected List<String> getCamposObrigatorios() {
		List<String> list = new ArrayList<>();
		list.add("nome_filme");
		return list;
	}

}
