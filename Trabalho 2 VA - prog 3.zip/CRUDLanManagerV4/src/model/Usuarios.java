package model;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import conversores.DateConversor;
import conversores.IntegerConversor;
import conversores.StringConversor;
import conversores.TabelaConversor;
import interfaces.IConversor;
import modelo.Tabela;
import util.Retorno;

public class Usuarios extends Tabela<Integer> {

	private String 	nome;
	private String 	email;
	private String 	senha;

	
	@Override
	public String getTabelaPKNome() {
		return "iduser";
	}

	

	@Override
	public String getTabelaNome() {
		return "usuarios";
	}

	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getSenha() {
		return senha;
	}



	public void setSenha(String senha) {
		this.senha = senha;
	}



	@Override
	public List<String> getCamposNome(){
		ArrayList<String> listNomes = new ArrayList<>();
		listNomes.add("iduser");
		listNomes.add("nome");
		listNomes.add("email");
		listNomes.add("senha");

		return listNomes ;
	}

	@Override
	protected Retorno setCamposValor(List<Object> list) {
		Retorno ret = new Retorno(true, "OK");
		try{
			this.setPk((Integer) list.get(0));
			this.setNome((String) list.get(1));
			this.setEmail((String) list.get(2));
			this.setSenha((String) list.get(3));
			//tem que tratar para dados estrangeiros
			/*Tipo t = new Tipo();
			t.setPk((Integer)list.get(4));
			t = this.getDadosExtrangeiro(t);			
			this.setTipo(t); */
			 
		}catch(Exception e){
			ret.setSucesso(false);
			ret.setMensagem("Erro ao configura campos, ERROR:"+e.getMessage());
		}
				
		return ret;
	}
	
	@Override
	public List<Object> getCamposValor() {
		ArrayList<Object> list = new ArrayList<>();

		list.add(this.getPk());
		list.add(this.getNome());
		list.add(this.getEmail());
		list.add(this.getSenha());



		return list;
	}
	
//--
	@Override
	public Tabela<?> getNovoObjeto() {
		return new Usuarios();
	}
	
	@Override
	public List<IConversor> getCamposConversor() {
		ArrayList<IConversor> listConversor = new ArrayList<>();
		listConversor.add(new IntegerConversor());//pk		
		listConversor.add(new StringConversor());//nome
		listConversor.add(new StringConversor());//email
		listConversor.add(new StringConversor());//senha
		return listConversor ;
	}
	@Override
	protected List<String> getCamposObrigatorios() {
		List<String> list = new ArrayList<>();
		list.add("email");
		list.add("senha");
		return list;
	}

}
