truncate table equipamento;
truncate table porta_vlan;
truncate table porta cascade;
truncate table switch cascade;
truncate table tipo cascade;
truncate table vlan cascade;